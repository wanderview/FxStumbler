cat ./vendor/promise.js ./src/drivers/*.js ./src/localForage.js > ./dist/localForage.js
